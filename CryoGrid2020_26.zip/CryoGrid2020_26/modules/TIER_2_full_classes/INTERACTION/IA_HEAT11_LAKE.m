classdef IA_HEAT11_LAKE <  IA_HEAT 
    
    methods
        
        function get_boundary_condition_m(ia_heat)
            get_boundary_condition_HEAT_LAKE_m(ia_heat);
        end
           
    end
end