function result = issingle(obj)
    result = all(size(obj) == 1) ;
end