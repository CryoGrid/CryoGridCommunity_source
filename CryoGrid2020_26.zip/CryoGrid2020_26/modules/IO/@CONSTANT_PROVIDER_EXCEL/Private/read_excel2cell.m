function result = read_excel2cell(filename)
    [dummy1, dummy2, result] = xlsread(filename);