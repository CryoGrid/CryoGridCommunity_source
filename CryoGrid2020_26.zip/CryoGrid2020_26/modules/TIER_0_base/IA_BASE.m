classdef IA_BASE < matlab.mixin.Copyable 

     properties
        PREVIOUS
        NEXT
     end
end